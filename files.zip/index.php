<?php
session_start();
require_once 'config/database.php';
require_once 'includes/Auth.php';
require_once 'models/Beneficiary.php';
require_once 'models/Proponent.php';

$auth = new Auth();
$auth->requireLogin();

$beneficiaryModel = new Beneficiary();
$proponentModel = new Proponent();

// Get statistics
$beneficiaryStats = $beneficiaryModel->getStatistics();
$proponentStats = $proponentModel->getStatistics();

// Get map data
$beneficiaryMapData = $beneficiaryModel->getMapData();
$proponentMapData = $proponentModel->getMapData();
$mapData = array_merge($beneficiaryMapData, $proponentMapData);

// Get overdue liquidations
$overdueLiquidations = $proponentModel->getOverdueLiquidations();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DOLE DILP Monitoring System - Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <style>
        :root {
            --dole-primary: #0066cc;
            --dole-secondary: #003d7a;
            --dole-success: #28a745;
            --dole-warning: #ffc107;
            --dole-danger: #dc3545;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
        }
        
        .navbar {
            background: linear-gradient(135deg, var(--dole-secondary), var(--dole-primary));
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .navbar-brand {
            font-weight: 600;
            font-size: 1.25rem;
        }
        
        .stat-card {
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            transition: transform 0.2s;
            border: none;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
        }
        
        .stat-card .card-body {
            padding: 1.5rem;
        }
        
        .stat-icon {
            font-size: 2.5rem;
            opacity: 0.8;
        }
        
        #map {
            height: 600px;
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        
        .alert-overdue {
            border-left: 4px solid var(--dole-danger);
        }
        
        .leaflet-popup-content-wrapper {
            border-radius: 8px;
        }
        
        .sidebar {
            background-color: white;
            min-height: calc(100vh - 56px);
            box-shadow: 2px 0 4px rgba(0,0,0,0.05);
        }
        
        .nav-link {
            color: #495057;
            padding: 0.75rem 1rem;
            border-radius: 5px;
            margin-bottom: 0.25rem;
            transition: all 0.2s;
        }
        
        .nav-link:hover {
            background-color: #e9ecef;
            color: var(--dole-primary);
        }
        
        .nav-link.active {
            background-color: var(--dole-primary);
            color: white;
        }
        
        .nav-link i {
            margin-right: 0.5rem;
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="index.php">
                <i class="bi bi-shield-check"></i> DOLE DILP Monitoring System
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                            <i class="bi bi-person-circle"></i> <?php echo htmlspecialchars($_SESSION['full_name']); ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="profile.php"><i class="bi bi-person"></i> Profile</a></li>
                            <li><a class="dropdown-item" href="change-password.php"><i class="bi bi-key"></i> Change Password</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logout.php"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <nav class="col-md-2 d-md-block sidebar p-3">
                <div class="position-sticky">
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link active" href="index.php">
                                <i class="bi bi-speedometer2"></i> Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="beneficiaries.php">
                                <i class="bi bi-person"></i> Beneficiaries
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="proponents.php">
                                <i class="bi bi-people"></i> Proponents
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="reports.php">
                                <i class="bi bi-file-earmark-text"></i> Reports
                            </a>
                        </li>
                        <?php if ($auth->hasRole('admin')): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="users.php">
                                <i class="bi bi-people-fill"></i> User Management
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="activity-logs.php">
                                <i class="bi bi-clock-history"></i> Activity Logs
                            </a>
                        </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </nav>

            <!-- Main Content -->
            <main class="col-md-10 ms-sm-auto px-md-4 py-4">
                <h2 class="mb-4">Dashboard Overview</h2>

                <!-- Statistics Cards -->
                <div class="row mb-4">
                    <div class="col-md-3 mb-3">
                        <div class="card stat-card bg-primary text-white">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="card-title text-uppercase mb-1">Total Beneficiaries</h6>
                                        <h2 class="mb-0"><?php echo number_format($beneficiaryStats['total']); ?></h2>
                                        <small>Male: <?php echo number_format($beneficiaryStats['male_count']); ?> | Female: <?php echo number_format($beneficiaryStats['female_count']); ?></small>
                                    </div>
                                    <i class="bi bi-person stat-icon"></i>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3 mb-3">
                        <div class="card stat-card bg-success text-white">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="card-title text-uppercase mb-1">Total Proponents</h6>
                                        <h2 class="mb-0"><?php echo number_format($proponentStats['total']); ?></h2>
                                        <small>LGU: <?php echo number_format($proponentStats['lgu_count']); ?> | Non-LGU: <?php echo number_format($proponentStats['non_lgu_count']); ?></small>
                                    </div>
                                    <i class="bi bi-people stat-icon"></i>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3 mb-3">
                        <div class="card stat-card bg-info text-white">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="card-title text-uppercase mb-1">Total Beneficiaries (Groups)</h6>
                                        <h2 class="mb-0"><?php echo number_format($proponentStats['total_beneficiaries'] ?? 0); ?></h2>
                                        <small>Male: <?php echo number_format($proponentStats['total_male'] ?? 0); ?> | Female: <?php echo number_format($proponentStats['total_female'] ?? 0); ?></small>
                                    </div>
                                    <i class="bi bi-people-fill stat-icon"></i>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3 mb-3">
                        <div class="card stat-card bg-warning text-dark">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="card-title text-uppercase mb-1">Total Amount</h6>
                                        <h2 class="mb-0">₱<?php echo number_format($beneficiaryStats['total_amount'] + $proponentStats['total_amount'], 2); ?></h2>
                                        <small>Individual + Group Projects</small>
                                    </div>
                                    <i class="bi bi-cash-stack stat-icon"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Project Status Overview -->
                <div class="row mb-4">
                    <div class="col-md-6">
                        <div class="card stat-card">
                            <div class="card-header bg-white">
                                <h5 class="mb-0"><i class="bi bi-person"></i> Individual Beneficiaries Status</h5>
                            </div>
                            <div class="card-body">
                                <div class="row text-center">
                                    <div class="col-3">
                                        <h4 class="text-secondary"><?php echo $beneficiaryStats['pending']; ?></h4>
                                        <small>Pending</small>
                                    </div>
                                    <div class="col-3">
                                        <h4 class="text-primary"><?php echo $beneficiaryStats['approved']; ?></h4>
                                        <small>Approved</small>
                                    </div>
                                    <div class="col-3">
                                        <h4 class="text-success"><?php echo $beneficiaryStats['implemented']; ?></h4>
                                        <small>Implemented</small>
                                    </div>
                                    <div class="col-3">
                                        <h4 class="text-info"><?php echo $beneficiaryStats['monitored']; ?></h4>
                                        <small>Monitored</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="card stat-card">
                            <div class="card-header bg-white">
                                <h5 class="mb-0"><i class="bi bi-people"></i> Group Proponents Status</h5>
                            </div>
                            <div class="card-body">
                                <div class="row text-center">
                                    <div class="col">
                                        <h4 class="text-secondary"><?php echo $proponentStats['pending']; ?></h4>
                                        <small>Pending</small>
                                    </div>
                                    <div class="col">
                                        <h4 class="text-primary"><?php echo $proponentStats['approved']; ?></h4>
                                        <small>Approved</small>
                                    </div>
                                    <div class="col">
                                        <h4 class="text-success"><?php echo $proponentStats['implemented']; ?></h4>
                                        <small>Implemented</small>
                                    </div>
                                    <div class="col">
                                        <h4 class="text-warning"><?php echo $proponentStats['liquidated']; ?></h4>
                                        <small>Liquidated</small>
                                    </div>
                                    <div class="col">
                                        <h4 class="text-info"><?php echo $proponentStats['monitored']; ?></h4>
                                        <small>Monitored</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Overdue Liquidations Alert -->
                <?php if (count($overdueLiquidations) > 0): ?>
                <div class="alert alert-danger alert-overdue mb-4" role="alert">
                    <h5 class="alert-heading"><i class="bi bi-exclamation-triangle-fill"></i> Overdue Liquidations</h5>
                    <p>There are <strong><?php echo count($overdueLiquidations); ?></strong> proponent(s) with overdue liquidation deadlines:</p>
                    <ul class="mb-0">
                        <?php foreach (array_slice($overdueLiquidations, 0, 5) as $overdue): ?>
                        <li>
                            <strong><?php echo htmlspecialchars($overdue['proponent_name']); ?></strong> - 
                            Deadline: <?php echo date('F d, Y', strtotime($overdue['liquidation_deadline'])); ?>
                            (<?php echo abs((strtotime($overdue['liquidation_deadline']) - time()) / 86400); ?> days overdue)
                        </li>
                        <?php endforeach; ?>
                    </ul>
                    <?php if (count($overdueLiquidations) > 5): ?>
                    <p class="mt-2 mb-0"><a href="proponents.php?filter=overdue" class="alert-link">View all overdue liquidations</a></p>
                    <?php endif; ?>
                </div>
                <?php endif; ?>

                <!-- Map Visualization -->
                <div class="card stat-card mb-4">
                    <div class="card-header bg-white">
                        <h5 class="mb-0"><i class="bi bi-geo-alt-fill"></i> Project Distribution Map - Negros Occidental</h5>
                    </div>
                    <div class="card-body p-0">
                        <div id="map"></div>
                    </div>
                    <div class="card-footer bg-white">
                        <div class="row text-center">
                            <div class="col-6">
                                <span class="badge bg-primary me-2">●</span> Individual Beneficiaries
                            </div>
                            <div class="col-6">
                                <span class="badge bg-success me-2">●</span> Group Proponents
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <script>
        // Initialize map centered on Negros Occidental
        var map = L.map('map').setView([10.5, 123.0], 9);

        // Add OpenStreetMap tile layer
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '© OpenStreetMap contributors',
            maxZoom: 18
        }).addTo(map);

        // Custom markers
        var beneficiaryIcon = L.icon({
            iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-blue.png',
            shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png',
            iconSize: [25, 41],
            iconAnchor: [12, 41],
            popupAnchor: [1, -34],
            shadowSize: [41, 41]
        });

        var proponentIcon = L.icon({
            iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-green.png',
            shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png',
            iconSize: [25, 41],
            iconAnchor: [12, 41],
            popupAnchor: [1, -34],
            shadowSize: [41, 41]
        });

        // Add markers from PHP data
        var mapData = <?php echo json_encode($mapData); ?>;
        
        mapData.forEach(function(item) {
            if (item.latitude && item.longitude) {
                var icon = item.type === 'beneficiary' ? beneficiaryIcon : proponentIcon;
                var popupContent = '<div style="min-width: 200px;">' +
                    '<h6 class="mb-2">' + item.name + '</h6>' +
                    '<p class="mb-1"><strong>Project:</strong> ' + (item.project_title || item.project_name) + '</p>' +
                    '<p class="mb-1"><strong>Location:</strong> ' + (item.barangay ? item.barangay + ', ' : '') + (item.municipality || item.district) + '</p>' +
                    '<p class="mb-1"><strong>Amount:</strong> ₱' + parseFloat(item.amount_worth || item.amount).toLocaleString('en-PH', {minimumFractionDigits: 2}) + '</p>';
                
                if (item.type === 'proponent') {
                    popupContent += '<p class="mb-1"><strong>Beneficiaries:</strong> ' + item.total_beneficiaries + '</p>';
                }
                
                popupContent += '<p class="mb-0"><span class="badge bg-' + getStatusColor(item.status) + '">' + capitalizeFirst(item.status) + '</span></p>' +
                    '</div>';
                
                L.marker([item.latitude, item.longitude], {icon: icon})
                    .addTo(map)
                    .bindPopup(popupContent);
            }
        });

        function getStatusColor(status) {
            switch(status) {
                case 'pending': return 'secondary';
                case 'approved': return 'primary';
                case 'implemented': return 'success';
                case 'liquidated': return 'warning';
                case 'monitored': return 'info';
                default: return 'secondary';
            }
        }

        function capitalizeFirst(str) {
            return str.charAt(0).toUpperCase() + str.slice(1);
        }
    </script>
</body>
</html>
