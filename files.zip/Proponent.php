<?php
// models/Proponent.php
// Model for Group Proponents

class Proponent {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }
    
    public function create($data) {
        $sql = "INSERT INTO proponents (
            proponent_type, date_received, noted_findings, control_number, number_of_copies,
            date_copies_received, district, proponent_name, project_title, amount,
            number_of_associations, total_beneficiaries, male_beneficiaries, female_beneficiaries,
            type_of_beneficiaries, category, recipient_barangays, letter_of_intent_date,
            date_forwarded_to_ro6, rpmt_findings, date_complied_by_proponent,
            date_complied_by_proponent_nofo, date_forwarded_to_nofo, date_approved,
            date_check_release, check_number, check_date_issued, or_number, or_date_issued,
            date_turnover, date_implemented, date_liquidated, date_monitoring,
            source_of_funds, latitude, longitude, status, created_by, updated_by
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        $stmt = $this->db->prepare($sql);
        $result = $stmt->execute([
            $data['proponent_type'], $data['date_received'], $data['noted_findings'],
            $data['control_number'], $data['number_of_copies'], $data['date_copies_received'],
            $data['district'], $data['proponent_name'], $data['project_title'], $data['amount'],
            $data['number_of_associations'], $data['total_beneficiaries'],
            $data['male_beneficiaries'], $data['female_beneficiaries'],
            $data['type_of_beneficiaries'], $data['category'], $data['recipient_barangays'],
            $data['letter_of_intent_date'], $data['date_forwarded_to_ro6'], $data['rpmt_findings'],
            $data['date_complied_by_proponent'], $data['date_complied_by_proponent_nofo'],
            $data['date_forwarded_to_nofo'], $data['date_approved'], $data['date_check_release'],
            $data['check_number'], $data['check_date_issued'], $data['or_number'],
            $data['or_date_issued'], $data['date_turnover'], $data['date_implemented'],
            $data['date_liquidated'], $data['date_monitoring'], $data['source_of_funds'],
            $data['latitude'], $data['longitude'], $data['status'],
            $_SESSION['user_id'], $_SESSION['user_id']
        ]);
        
        if ($result) {
            $this->logActivity('create', $this->db->lastInsertId(), 'Created new proponent');
            return $this->db->lastInsertId();
        }
        
        return false;
    }
    
    public function update($id, $data) {
        $sql = "UPDATE proponents SET
            proponent_type = ?, date_received = ?, noted_findings = ?, control_number = ?,
            number_of_copies = ?, date_copies_received = ?, district = ?, proponent_name = ?,
            project_title = ?, amount = ?, number_of_associations = ?, total_beneficiaries = ?,
            male_beneficiaries = ?, female_beneficiaries = ?, type_of_beneficiaries = ?,
            category = ?, recipient_barangays = ?, letter_of_intent_date = ?,
            date_forwarded_to_ro6 = ?, rpmt_findings = ?, date_complied_by_proponent = ?,
            date_complied_by_proponent_nofo = ?, date_forwarded_to_nofo = ?, date_approved = ?,
            date_check_release = ?, check_number = ?, check_date_issued = ?, or_number = ?,
            or_date_issued = ?, date_turnover = ?, date_implemented = ?, date_liquidated = ?,
            date_monitoring = ?, source_of_funds = ?, latitude = ?, longitude = ?, status = ?,
            updated_by = ?
        WHERE id = ?";
        
        $stmt = $this->db->prepare($sql);
        $result = $stmt->execute([
            $data['proponent_type'], $data['date_received'], $data['noted_findings'],
            $data['control_number'], $data['number_of_copies'], $data['date_copies_received'],
            $data['district'], $data['proponent_name'], $data['project_title'], $data['amount'],
            $data['number_of_associations'], $data['total_beneficiaries'],
            $data['male_beneficiaries'], $data['female_beneficiaries'],
            $data['type_of_beneficiaries'], $data['category'], $data['recipient_barangays'],
            $data['letter_of_intent_date'], $data['date_forwarded_to_ro6'], $data['rpmt_findings'],
            $data['date_complied_by_proponent'], $data['date_complied_by_proponent_nofo'],
            $data['date_forwarded_to_nofo'], $data['date_approved'], $data['date_check_release'],
            $data['check_number'], $data['check_date_issued'], $data['or_number'],
            $data['or_date_issued'], $data['date_turnover'], $data['date_implemented'],
            $data['date_liquidated'], $data['date_monitoring'], $data['source_of_funds'],
            $data['latitude'], $data['longitude'], $data['status'],
            $_SESSION['user_id'], $id
        ]);
        
        if ($result) {
            $this->logActivity('update', $id, 'Updated proponent');
        }
        
        return $result;
    }
    
    public function delete($id) {
        $stmt = $this->db->prepare("DELETE FROM proponents WHERE id = ?");
        $result = $stmt->execute([$id]);
        
        if ($result) {
            $this->logActivity('delete', $id, 'Deleted proponent');
        }
        
        return $result;
    }
    
    public function findById($id) {
        $stmt = $this->db->prepare("SELECT * FROM proponents WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch();
    }
    
    public function getAll($filters = []) {
        $sql = "SELECT * FROM proponents WHERE 1=1";
        $params = [];
        
        if (!empty($filters['proponent_type'])) {
            $sql .= " AND proponent_type = ?";
            $params[] = $filters['proponent_type'];
        }
        
        if (!empty($filters['district'])) {
            $sql .= " AND district = ?";
            $params[] = $filters['district'];
        }
        
        if (!empty($filters['status'])) {
            $sql .= " AND status = ?";
            $params[] = $filters['status'];
        }
        
        if (!empty($filters['category'])) {
            $sql .= " AND category = ?";
            $params[] = $filters['category'];
        }
        
        if (!empty($filters['date_from'])) {
            $sql .= " AND date_approved >= ?";
            $params[] = $filters['date_from'];
        }
        
        if (!empty($filters['date_to'])) {
            $sql .= " AND date_approved <= ?";
            $params[] = $filters['date_to'];
        }
        
        if (!empty($filters['search'])) {
            $sql .= " AND (proponent_name LIKE ? OR project_title LIKE ? OR control_number LIKE ?)";
            $searchTerm = '%' . $filters['search'] . '%';
            $params[] = $searchTerm;
            $params[] = $searchTerm;
            $params[] = $searchTerm;
        }
        
        $sql .= " ORDER BY created_at DESC";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }
    
    public function getMapData() {
        $sql = "SELECT id, proponent_name as name, project_title, district, amount, 
                latitude, longitude, status, proponent_type, 'proponent' as type,
                total_beneficiaries
                FROM proponents 
                WHERE status IN ('approved', 'implemented', 'liquidated', 'monitored') 
                AND latitude IS NOT NULL AND longitude IS NOT NULL";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll();
    }
    
    public function getStatistics() {
        $sql = "SELECT 
            COUNT(*) as total,
            SUM(CASE WHEN proponent_type = 'LGU-associated' THEN 1 ELSE 0 END) as lgu_count,
            SUM(CASE WHEN proponent_type = 'Non-LGU-associated' THEN 1 ELSE 0 END) as non_lgu_count,
            SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
            SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) as approved,
            SUM(CASE WHEN status = 'implemented' THEN 1 ELSE 0 END) as implemented,
            SUM(CASE WHEN status = 'liquidated' THEN 1 ELSE 0 END) as liquidated,
            SUM(CASE WHEN status = 'monitored' THEN 1 ELSE 0 END) as monitored,
            SUM(total_beneficiaries) as total_beneficiaries,
            SUM(male_beneficiaries) as total_male,
            SUM(female_beneficiaries) as total_female,
            SUM(amount) as total_amount
        FROM proponents";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        return $stmt->fetch();
    }
    
    public function getOverdueLiquidations() {
        $sql = "SELECT * FROM proponents 
                WHERE date_liquidated IS NULL 
                AND liquidation_deadline < CURDATE() 
                AND status != 'liquidated'
                ORDER BY liquidation_deadline ASC";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll();
    }
    
    private function logActivity($action, $recordId, $description) {
        $stmt = $this->db->prepare(
            "INSERT INTO activity_logs (user_id, action, table_name, record_id, description, ip_address) 
             VALUES (?, ?, 'proponents', ?, ?, ?)"
        );
        $stmt->execute([
            $_SESSION['user_id'],
            $action,
            $recordId,
            $description,
            $_SERVER['REMOTE_ADDR'] ?? 'unknown'
        ]);
    }
}
