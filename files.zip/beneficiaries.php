<?php
session_start();
require_once 'config/database.php';
require_once 'includes/Auth.php';
require_once 'models/Beneficiary.php';

$auth = new Auth();
$auth->requireLogin();

$beneficiaryModel = new Beneficiary();

// Get filters from query string
$filters = [
    'municipality' => $_GET['municipality'] ?? '',
    'barangay' => $_GET['barangay'] ?? '',
    'status' => $_GET['status'] ?? '',
    'search' => $_GET['search'] ?? ''
];

// Get beneficiaries
$beneficiaries = $beneficiaryModel->getAll($filters);

// Get unique municipalities and barangays for filters
$db = Database::getInstance()->getConnection();
$municipalities = $db->query("SELECT DISTINCT municipality FROM beneficiaries ORDER BY municipality")->fetchAll(PDO::FETCH_COLUMN);
$barangays = $db->query("SELECT DISTINCT barangay FROM beneficiaries ORDER BY barangay")->fetchAll(PDO::FETCH_COLUMN);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Beneficiaries - DOLE DILP Monitoring System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .navbar {
            background: linear-gradient(135deg, #003d7a, #0066cc);
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .sidebar {
            background-color: white;
            min-height: calc(100vh - 56px);
            box-shadow: 2px 0 4px rgba(0,0,0,0.05);
        }
        
        .nav-link {
            color: #495057;
            padding: 0.75rem 1rem;
            border-radius: 5px;
            margin-bottom: 0.25rem;
            transition: all 0.2s;
        }
        
        .nav-link:hover {
            background-color: #e9ecef;
            color: #0066cc;
        }
        
        .nav-link.active {
            background-color: #0066cc;
            color: white;
        }
        
        .card {
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            border: none;
        }
        
        .badge-status {
            padding: 0.5rem 0.75rem;
            font-weight: 500;
        }
        
        .action-btn {
            padding: 0.25rem 0.5rem;
            margin: 0 0.125rem;
        }
        
        .filters-card {
            background-color: #f8f9fa;
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="index.php">
                <i class="bi bi-shield-check"></i> DOLE DILP Monitoring System
            </a>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                            <i class="bi bi-person-circle"></i> <?php echo htmlspecialchars($_SESSION['full_name']); ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="profile.php"><i class="bi bi-person"></i> Profile</a></li>
                            <li><a class="dropdown-item" href="change-password.php"><i class="bi bi-key"></i> Change Password</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logout.php"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <nav class="col-md-2 d-md-block sidebar p-3">
                <div class="position-sticky">
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link" href="index.php">
                                <i class="bi bi-speedometer2"></i> Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" href="beneficiaries.php">
                                <i class="bi bi-person"></i> Beneficiaries
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="proponents.php">
                                <i class="bi bi-people"></i> Proponents
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="reports.php">
                                <i class="bi bi-file-earmark-text"></i> Reports
                            </a>
                        </li>
                        <?php if ($auth->hasRole('admin')): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="users.php">
                                <i class="bi bi-people-fill"></i> User Management
                            </a>
                        </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </nav>

            <!-- Main Content -->
            <main class="col-md-10 ms-sm-auto px-md-4 py-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2><i class="bi bi-person"></i> Individual Beneficiaries</h2>
                    <?php if ($auth->hasRole(['admin', 'encoder'])): ?>
                    <a href="beneficiary-form.php" class="btn btn-primary">
                        <i class="bi bi-plus-circle"></i> Add New Beneficiary
                    </a>
                    <?php endif; ?>
                </div>

                <!-- Filters -->
                <div class="card filters-card mb-4">
                    <div class="card-body">
                        <form method="GET" action="" class="row g-3">
                            <div class="col-md-3">
                                <label class="form-label">Search</label>
                                <input type="text" name="search" class="form-control" 
                                       placeholder="Name or Project" value="<?php echo htmlspecialchars($filters['search']); ?>">
                            </div>
                            <div class="col-md-2">
                                <label class="form-label">Municipality</label>
                                <select name="municipality" class="form-select">
                                    <option value="">All</option>
                                    <?php foreach ($municipalities as $municipality): ?>
                                    <option value="<?php echo htmlspecialchars($municipality); ?>" 
                                            <?php echo $filters['municipality'] === $municipality ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($municipality); ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <label class="form-label">Barangay</label>
                                <select name="barangay" class="form-select">
                                    <option value="">All</option>
                                    <?php foreach ($barangays as $barangay): ?>
                                    <option value="<?php echo htmlspecialchars($barangay); ?>" 
                                            <?php echo $filters['barangay'] === $barangay ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($barangay); ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <label class="form-label">Status</label>
                                <select name="status" class="form-select">
                                    <option value="">All</option>
                                    <option value="pending" <?php echo $filters['status'] === 'pending' ? 'selected' : ''; ?>>Pending</option>
                                    <option value="approved" <?php echo $filters['status'] === 'approved' ? 'selected' : ''; ?>>Approved</option>
                                    <option value="implemented" <?php echo $filters['status'] === 'implemented' ? 'selected' : ''; ?>>Implemented</option>
                                    <option value="monitored" <?php echo $filters['status'] === 'monitored' ? 'selected' : ''; ?>>Monitored</option>
                                </select>
                            </div>
                            <div class="col-md-3 d-flex align-items-end gap-2">
                                <button type="submit" class="btn btn-primary">
                                    <i class="bi bi-search"></i> Filter
                                </button>
                                <a href="beneficiaries.php" class="btn btn-secondary">
                                    <i class="bi bi-x-circle"></i> Clear
                                </a>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Beneficiaries Table -->
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="beneficiariesTable" class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Full Name</th>
                                        <th>Gender</th>
                                        <th>Location</th>
                                        <th>Project Name</th>
                                        <th>Amount</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($beneficiaries as $beneficiary): ?>
                                    <tr>
                                        <td><?php echo $beneficiary['id']; ?></td>
                                        <td>
                                            <?php echo htmlspecialchars($beneficiary['first_name'] . ' ' . 
                                                      ($beneficiary['middle_name'] ? substr($beneficiary['middle_name'], 0, 1) . '. ' : '') . 
                                                      $beneficiary['last_name'] . 
                                                      ($beneficiary['suffix'] ? ' ' . $beneficiary['suffix'] : '')); ?>
                                        </td>
                                        <td><?php echo htmlspecialchars($beneficiary['gender']); ?></td>
                                        <td><?php echo htmlspecialchars($beneficiary['barangay'] . ', ' . $beneficiary['municipality']); ?></td>
                                        <td><?php echo htmlspecialchars($beneficiary['project_name']); ?></td>
                                        <td>₱<?php echo number_format($beneficiary['amount_worth'], 2); ?></td>
                                        <td>
                                            <?php
                                            $statusColors = [
                                                'pending' => 'secondary',
                                                'approved' => 'primary',
                                                'implemented' => 'success',
                                                'monitored' => 'info'
                                            ];
                                            $color = $statusColors[$beneficiary['status']] ?? 'secondary';
                                            ?>
                                            <span class="badge bg-<?php echo $color; ?> badge-status">
                                                <?php echo ucfirst($beneficiary['status']); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <a href="beneficiary-view.php?id=<?php echo $beneficiary['id']; ?>" 
                                               class="btn btn-sm btn-info action-btn" title="View">
                                                <i class="bi bi-eye"></i>
                                            </a>
                                            <?php if ($auth->hasRole(['admin', 'encoder'])): ?>
                                            <a href="beneficiary-form.php?id=<?php echo $beneficiary['id']; ?>" 
                                               class="btn btn-sm btn-warning action-btn" title="Edit">
                                                <i class="bi bi-pencil"></i>
                                            </a>
                                            <?php if ($auth->hasRole('admin')): ?>
                                            <button onclick="deleteBeneficiary(<?php echo $beneficiary['id']; ?>)" 
                                                    class="btn btn-sm btn-danger action-btn" title="Delete">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                            <?php endif; ?>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#beneficiariesTable').DataTable({
                order: [[0, 'desc']],
                pageLength: 25,
                language: {
                    search: "Search:",
                    lengthMenu: "Show _MENU_ entries",
                    info: "Showing _START_ to _END_ of _TOTAL_ beneficiaries"
                }
            });
        });

        function deleteBeneficiary(id) {
            if (confirm('Are you sure you want to delete this beneficiary? This action cannot be undone.')) {
                window.location.href = 'beneficiary-delete.php?id=' + id;
            }
        }
    </script>
</body>
</html>
